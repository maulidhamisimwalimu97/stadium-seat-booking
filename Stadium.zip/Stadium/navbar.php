<!DOCTYPE html>
<html>
<head>
	<style>
	* {box-sizing: border-box;}
	body {font-family: Verdana, sans-serif;}
	.mySlides {display: none;}
	img {vertical-align:;}

	/* Slideshow container */
	.slideshow-container {
	max-width: 1000px;
	position: relative;
	margin: auto;
	}

	/* Caption text */
	.text {
	color: #f2f2f2;
	font-size: 15px;
	padding: 8px 12px;
	position: absolute;
	bottom: 8px;
	width: 100%;
	text-align: center;
	}

	/* Number text (1/3 etc) */
	.numbertext {
	color: #f2f2f2;
	font-size: 12px;
	padding: 8px 12px;
	position: absolute;
	top: 0;
	}

	/* The dots/bullets/indicators */
	.dot {
	height: 15px;
	width: 15px;
	margin: 0 2px;
	background-color: #bbb;
	border-radius: 50%;
	display: inline-block;
	transition: background-color 0.1s ease;
	}

	.active {
	background-color: #717171;
	}

	/* Fading animation */
	.fade {
	animation-name: fade;
	animation-duration: 10s;
	}

	@keyframes fade {
	from {opacity: .4} 
	to {opacity: 1}
	}

	/* On smaller screens, decrease text size */
	@media only screen and (max-width: 300px) {
	.text {font-size: 11px}
	}
	</style>

	<title>User panel</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	<link rel="stylesheet" href="CSS/birthii.css">
	<link rel="stylesheet" href="CSS/style.css">
</head>
<body onLoad="imageChanger();">
	<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
		<div class="container">
			    <a class="navbar-brand" href="#">Stadium Seat Booking</a>
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
			</button>
			<div class="collapse navbar-collapse" id="navbarNav">
				<ul class="navbar-nav ml-auto">
					<li class="nav-item">
						<a class="nav-link active" href="user.php">Home</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="choose stadiums.php">booking for seat</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="event.php">Check Events</a>
					</li>
					<li class="nav-item">
							<a class="nav-link" href="">Change Password</a>
					</li>
					<li class="nav-item">
							<a class="nav-link" href="">Logout</a>
					</li>
					<!-- <li class="nav-item">
						<a class="nav-link" href="#">About us</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="#">Contact us</a>
					</li> -->
				</ul>
			</div>
		</div>
	</nav>