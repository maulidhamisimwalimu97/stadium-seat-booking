<?php require_once('navbar.php'); ?>

<div class="full-container">
<div class="mySlides light">
  <img src="images/3.jpg" style="width:100%; height:103%;">
  <div class="text">Our Stadium</div>
</div>

<!-- <div class="mySlides light">
  <img src="images/2.jpg" style="width:100%; height:103%;">
  <div class="text">Caption two</div>
</div> -->

<div class="mySlides light">
  <img src="images/5.jpg" style="width:100%; height:103%;">
  <div class="text">Our Stadium</div>
</div>

<div class="mySlides light">
  <img src="images/6.jpg" style="width:100%; height:103%;">
  <div class="text">Our Stadium</div>
</div>

<div class="mySlides light">
  <img src="images/7.jpg" style="width:100%; height:103%;">
  <div class="text">Our Stadium</div>
</div>

<!-- <div class="mySlides light">
  <img src="images/5.jpg" style="width:100%; height:100%;">
  <div class="text">Caption five</div>
</div>

<!-- <div class="mySlides light">
  <img src="images/6.jpg" style="width:100%; height:100%;">
  <div class="text">Caption six</div>
</div>

<div class="mySlides light">
  <img src="images/7.jpg" style="width:100%; height:100%;">
  <div class="text">Caption seven</div>
</div> -->


<div style="text-align:center">
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span>
  <!-- <span class="dot"></span> 
  -->
</div>
</div>
		
		
	<script>
		let slideIndex = 0;
		showSlides();

		function showSlides() {
		let i;
		let slides = document.getElementsByClassName("mySlides");
		let dots = document.getElementsByClassName("dot");
		for (i = 0; i < slides.length; i++) {
			slides[i].style.display = "none";  
		}
		slideIndex++;
		if (slideIndex > slides.length) {slideIndex = 1}    
		for (i = 0; i < dots.length; i++) {
			dots[i].className = dots[i].className.replace(" active", "");
		}
		slides[slideIndex-1].style.display = "block";  
		dots[slideIndex-1].className += " active";
		setTimeout(showSlides, 2000); // Change image every 2 seconds
		}
	</script>
</body>
</html>

