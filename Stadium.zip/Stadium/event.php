<?php require_once('navbar.php');?>

    <!-- Birth Records Section -->
    <section id="birth-records">
      <div class="container">
        <div class="row">
          <div class="col-md-12 text-center">
            <h1>Stadium Seat Booking</h1>
            <p><b>Below are the match of the whole year.<b></p>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12">
            <table class="table table-striped">
              <thead>
                <tr>
                  <th>Serial No.</th>
                  <th>match</th>
                  <th>date</th>
                  <th>time</th>
                  <th>stadium</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>1</td>
                  <td>simba vs mtibwa</td>
                  <td>14/7/2023</td>
                  <td>20.00pm</td>
                  <td>mkapa stadium</td>
                </tr>
                
                <tr>
                  <td>2</td>
                  <td>simba vs yanga</td>
                  <td>17/7/2023</td>
                  <td>20.00pm</td>
                  <td>mkapa stadium</td>
                </tr>
                <tr>
                  <td>3</td>
                  <td>simba vs polisi</td>
                  <td>17/7/2023</td>
                  <td>20.00pm</td>
                  <td>mkapa stadium</td>
                </tr>
                <tr>
                  <td>4</td>
                  <td>simba vs namungo</td>
                  <td>17/7/2023</td>
                  <td>20.00pm</td>
                  <td>mkapa stadium</td>
                </tr>
                <tr>
                  <td>5</td>
                  <td>simba vs geita gold</td>
                  <td>17/7/2023</td>
                  <td>20.00pm</td>
                  <td>mkapa stadium</td>
                </tr>
                <tr>
                  <td>6</td>
                  <td>simba vs singida all stars</td>
                  <td>17/7/2023</td>
                  <td>20.00pm</td>
                  <td>mkapa stadium</td>
                </tr>
                <tr>
                  <td>7</td>
                  <td>simba vs mbeya city</td>
                  <td>17/7/2023</td>
                  <td>20.00pm</td>
                  <td>mkapa stadium</td>
                </tr>
                <tr>
                  <td>8</td>
                  <td>simba vs tanzania prison</td>
                  <td>17/7/2023</td>
                  <td>20.00pm</td>
                  <td>mkapa stadium</td>
                </tr>
                <tr>
                  <td>9</td>
                  <td>simba vs kmc</td>
                  <td>17/7/2023</td>
                  <td>20.00pm</td>
                  <td>mkapa stadium</td>
                </tr>
                <tr>
                  <td>10</td>
                  <td>simba vs azam</td>
                  <td>17/7/2023</td>
                  <td>20.00pm</td>
                  <td>mkapa stadium</td>
                </tr>
                <tr>
                  <td>11</td>
                  <td>simba vs ruvu shooting</td>
                  <td>17/7/2023</td>
                  <td>20.00pm</td>
                  <td>mkapa stadium</td>
                </tr>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </section>
    <!-- JavaScript Libraries -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  </body>
</html>