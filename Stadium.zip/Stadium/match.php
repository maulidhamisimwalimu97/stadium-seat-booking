<!DOCTYPE html>
<html>
  <head>
    <title>ADD Match Of The Year</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="CSS/born.css">
    <link rel="stylesheet" href="CSS/birthii.css">
	<link rel="stylesheet" href="CSS/style.css">
  </head>
  <body style="background-color:light;">
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
		<div class="container">
			    <!-- <a class="navbar-brand" href="#">Birth &amp; Death Profile System</a>
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
			</button>
			<div class="collapse navbar-collapse" id="navbarNav">
				<ul class="navbar-nav ml-auto">
					<li class="nav-item">
						<a class="nav-link active" href="home.php">Home</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="born.php">generate birth certificate</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="death.php">generate death certificate</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="records.php">Birth Records</a>
					</li>
					<li class="nav-item">
							<a class="nav-link" href="drecords.php">Death Records</a>
					</li>
					<!-- <li class="nav-item">
						<a class="nav-link" href="#">About us</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="#">Contact us</a>
					</li> -->
				</ul>
			</div>
		</div>
	</nav>

    <div class="container">
      <div class="row">
        <div class="col-md-12 text-center">
          <h1>Add new match</h1>
        </div>
      </div>
      <form action="match.php" method="POST">
        <div class="row">
          <div class="col-md-6">
            <div class="form-group">
              <label for="name">Match Name:</label>
              <input type="text" class="form-control" name="name">
            </div>
            <div class="form-group">
              <label for="dod">Date:</label>
              <input type="date" class="form-control" name="date">
            </div>
            <div class="form-group">
              <label for="place">Time:</label>
              <input type="time" class="form-control" name="time">
            </div>
            <div class="form-group">
              <label for="cause">location:</label>
              <input type="text" class="form-control" name="location">
            <button type="submit" name="submit" class="btn  btn-primary">REGISTER</button>  
            </form>
          </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  </body>
</html>
<?php
if(isset($_POST["submit"])){
$name = $_POST['name'];
$date = $_POST['date'];
$time = $_POST['time'];
$location = $_POST['location'];


$conn=mysqli_connect("127.0.0.1","root","","stadium");

$sql = "insert into match(name,date,time,location) values ('$name','$date','$time','$location')";
$query1=mysqli_query($conn,$sql) or die(mysqli_error($conn));
if($query1){
  echo '<script>alert("match generated")</script>';
}

else{
  echo '<script>alert("match not generated")</script>';

}
}
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

?>