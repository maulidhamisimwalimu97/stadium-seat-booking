<?php require_once('navbar.php'); ?>
<div class="container">
	<div class="row">
		<div class="col-md-4">
			<div class="card">
				<div class="card-header">
				</div>
				<div class="card-body my-4">
					<h4>Simba Vs Young African</h4>
					<a href="seatBooking.php">Booke Your Seat Now</a>
				</div>
			</div>
		</div>

		<div class="col-md-4">
			<div class="card">
				<div class="card-header">
				</div>
				<div class="card-body my-4">
					
					<a href="">Booke Your Seat Now</a>
				</div>
			</div>
		</div>

		<div class="col-md-4">
			<div class="card">
				<div class="card-body my-4">
					<h4>Simba Vs Young African</h4>
					<a href="">Booke Your Seat Now</a>
				</div>
			</div>
		</div>

		<div class="col-md-4">
			<div class="card">
				<div class="card-header">
				</div>
				<div class="card-body my-4">
					<h4>Simba Vs Young African</h4>
					<a href="">Booke Your Seat Now</a>
				</div>
			</div>
		</div>
	</div>
</div>


		

<style>
	/*.form-limit{
		width: 63%;
		margin-left: 265px;
		background: white;
		padding: 20px;
		box-shadow: 2px 2px 4px #000000 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
	}
*/	/*input[type="text"],input[type="number"] ,input[type="date"], select{
		width: 100%;
		height: 30px;
		box-shadow: 0px 0px 2px 0px;
		border-color: lightblue;
		border-top: none;
		border-left: none;
		border-right: none;
		border-radius: 6px;

	}*/

	.form{
		margin-top: 20px;
	}
	.text-center{
		text-align: center;
		padding: 33px;
		color: white;
	}
	.form-header{
		background: gray;
		height: 100px;
		border-radius: 4px;
	}
</style>
</body>
</html>


<!-- 
<?php
if(isset($_POST["submit"])){
	$station_name = $_POST["station_name"];


	$conn=mysqli_connect("127.0.0.1","root","","crime");
	$sql="insert into police_station(station_name) 
			values('$station_name')";

	$query1=mysqli_query($conn,$sql);
if($query1){
			echo '<script>alert("data sent")</script>';
		}

		else{
			echo '<script>alert("data not sent")</script>';
	
		}
	}

?>
 -->






