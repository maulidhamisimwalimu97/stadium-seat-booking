<!DOCTYPE html>
<html>
<head>
	<style>
	* {box-sizing: border-box;}
	body {font-family: Verdana, sans-serif;}
	.mySlides {display: none;}
	img {vertical-align:;}

	/* Slideshow container */
	.slideshow-container {
	max-width: 1000px;
	position: relative;
	margin: auto;
	}

	/* Caption text */
	.text {
	color: #f2f2f2;
	font-size: 15px;
	padding: 8px 12px;
	position: absolute;
	bottom: 8px;
	width: 100%;
	text-align: center;
	}

	/* Number text (1/3 etc) */
	.numbertext {
	color: #f2f2f2;
	font-size: 12px;
	padding: 8px 12px;
	position: absolute;
	top: 0;
	}

	/* The dots/bullets/indicators */
	.dot {
	height: 15px;
	width: 15px;
	margin: 0 2px;
	background-color: #bbb;
	border-radius: 50%;
	display: inline-block;
	transition: background-color 0.1s ease;
	}

	.active {
	background-color: #717171;
	}

	/* Fading animation */
	.fade {
	animation-name: fade;
	animation-duration: 10s;
	}

	@keyframes fade {
	from {opacity: .4} 
	to {opacity: 1}
	}

	/* On smaller screens, decrease text size */
	@media only screen and (max-width: 300px) {
	.text {font-size: 11px}
	}
	</style>

	<title>Admin panel</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	<link rel="stylesheet" href="CSS/birthii.css">
	<link rel="stylesheet" href="CSS/style.css">
</head>
<body onLoad="imageChanger();">
	<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
		<div class="container">
			    <a class="navbar-brand" href="#">Stadium Seat Booking</a>
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
			</button>
			<div class="collapse navbar-collapse" id="navbarNav">
				<ul class="navbar-nav ml-auto">
					<li class="nav-item">
						<a class="nav-link active" href="admin.php">Home</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="match.php">Manage Events</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="v.php">Manage Seat</a>
                    </li>
					<li class="nav-item">
							<a class="nav-link" href="">Change password</a>
					</li>
					<li class="nav-item">
							<a class="nav-link" href="">Logout</a>
					</li>
					<!-- <li class="nav-item">
						<a class="nav-link" href="#">About us</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="#">Contact us</a>
					</li> -->
				</ul>
			</div>
		</div>
	</nav>



<div class="full-container">
<div class="mySlides light">
  <img src="images/1.jpeg" style="width:100%; height:100%;">
  <div class="text">Caption one</div>
</div>

<div class="mySlides light">
  <img src="images/2.jpeg" style="width:100%; height:100%;">
  <div class="text">Caption Two</div>
</div>

<div class="mySlides light">
  <img src="images/3.jpg" style="width:100%; height:100%;">
  <div class="text">Caption Three</div>
</div>

<div class="mySlides light">
  <img src="images/4.jpg" style="width:100%; height:100%;">
  <div class="text">Caption four</div>
</div>

<!-- <div class="mySlides light">
  <img src="images/5.jpg" style="width:100%; height:100%;">
  <div class="text">Caption five</div>
</div>

<!-- <div class="mySlides light">
  <img src="images/6.jpg" style="width:100%; height:100%;">
  <div class="text">Caption six</div>
</div>

<div class="mySlides light">
  <img src="images/7.jpg" style="width:100%; height:100%;">
  <div class="text">Caption seven</div>
</div> -->


<div style="text-align:center">
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span> 
</div>
</div>
		
	<script>
		let slideIndex = 0;
		showSlides();

		function showSlides() {
		let i;
		let slides = document.getElementsByClassName("mySlides");
		let dots = document.getElementsByClassName("dot");
		for (i = 0; i < slides.length; i++) {
			slides[i].style.display = "none";  
		}
		slideIndex++;
		if (slideIndex > slides.length) {slideIndex = 1}    
		for (i = 0; i < dots.length; i++) {
			dots[i].className = dots[i].className.replace(" active", "");
		}
		slides[slideIndex-1].style.display = "block";  
		dots[slideIndex-1].className += " active";
		setTimeout(showSlides, 2000); // Change image every 2 seconds
		}
	</script>
</body>
	</html>